#!/usr/bin/python3
import os
import subprocess
import math
import random 
import time
import getpass
import LunUI as Lui
import getpass
import svc_EventSoundService as evsound

#Jade Menu

class Settings:
    def PinApps():
        os.system("clear")
        print("Change Entry Names")
        input()
        os.system("nano /users/"+getpass.getuser()+"/envd/environres/jade/namelist.txt")
        print("Change Entry Paths")
        input()
        os.system("nano /users/"+getpass.getuser()+"/envd/environres/jade/pathlist.txt")
        return

def power():
    os.system("clear")
    print("What do you want to do?")
    print("\nTurn off your Computer [1]")
    print("Terminal [2]")
    print("Settings [3]")
    print("\nCancel [#]")
    a = input()
    if a=="#":
        return;
    if a=="1":
        evsound.play("shutdown")
        os.system("sudo poweroff")
    #if a=="2":
        evsound.play("shutdown")
        os.system("loginctl terminate-user $USER")
    if a=="2":
        os.system("/bin/bash")
    if a=="3":
        os.system("python3 /lunathyst/sysset.py")
    return

class engine:
    def out(page):
        username=getpass.getuser()
        min = (page-1)*10
        max = (page*10)+1
        ind = 0
        with open("/apps/global/environres/namelist.txt") as globalf:
            namelist_global= [line.strip() for line in globalf]
        with open("/users/" + username + "/envd/environres/jade/namelist.txt") as namelist:
            namelist_singleuser = [line.strip() for line in namelist]
            namelist=namelist_global+namelist_singleuser
            for name in namelist:
                ind=ind+1
                if ind>min:
                    if ind<max:
                        print(str(ind)+". "+name)
        return
    def inp(page, chosenindex):
        try:
            int(chosenindex)
        except:
            return 1
        username=getpass.getuser()
        index=-1
        with open("/apps/global/environres/pathlist.txt") as globalf:
            pathlist_global=[line.strip() for line in globalf]
        with open("/users/" + username + "/envd/environres/jade/pathlist.txt") as pathlist:
            pathlist_singleuser=[line.strip() for line in pathlist]
            pathlist=pathlist_global+pathlist_singleuser
            for path in pathlist:
                index=index+1
                if str(int(int(chosenindex)-1))==str(index):
                    if "setsid" in path:
                        subprocess.Popen(["bash", "-c", path])
                    else:
                        os.system(path)
                    break
        return

def Main():
    username = getpass.getuser()
    page = 1
    while True:
        os.system("clear")
        Lui.v1.interaction.separator()
        Lui.v1.interaction.envpanel("Desktop")
        print(" Welcome " + username)
        print("[=] Show more options")
        print("Apps:\n")
        engine.out(page)
        print("< Previous Page | Next Page >" if page!=1 else "Next Page >")
        print("Page: "+str(page)); 
        a = input()
        if a=="#":
            exit(0)
        if a=="=":
            power()
        if a=="<" and page>1:
            if page!=1:
                page = page - 1; continue
        if a==">":
            page = page + 1; continue
        a=engine.inp(page, a)
        if a==1:
            print("Invalid Input!")
            input()
        continue
    return

Main()
