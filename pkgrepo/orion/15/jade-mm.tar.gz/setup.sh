#!/bin/bash
mkdir /users/$1/envd/environres/jade
echo Settings >> /users/$1/envd/environres/jade/namelist.txt
echo python3 /lunathyst/sysset.py >> /users/$1/envd/environres/jade/pathlist.txt
