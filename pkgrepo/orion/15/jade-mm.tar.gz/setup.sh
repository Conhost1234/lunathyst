#!/bin/bash
mkdir /users//envd/environres/jade
echo Settings >> /users/$USER/envd/environres/jade/namelist.txt
echo python3 /lunathyst/sysset.py >> /users/$USER/envd/environres/jade/pathlist.txt
