#!/usr/bin/python3
import os
import subprocess
import math
import random 
import time
import getpass
import LunUI as Lui
import getpass

#Jade Menu

class Settings:
    def PinApps():
        os.system("clear")
        print("Change Entry Names")
        input()
        os.system("nano /users/"+getpass.getuser()+"/envd/environres/jade/namelist.txt")
        print("Change Path Names (add \"setsid\" before the name if you're pinning a graphical app)")
        input()
        os.system("nano /users/"+getpass.getuser()+"/envd/environres/jade/pathlist.txt")
        return

def power():
    os.system("clear")
    print("What do you want to do?")
    print("\nTurn off your Computer [1]")
    print("Sign Out [2]")
    print("Settings [3]")
    print("\nCancel [#]")
    a = input()
    if a=="1":
        os.system("sudo poweroff")
    if a=="2":
        os.system("logoff")
    if a=="3":
        os.system("python3 /lunathyst/sysset.py")
    return

class engine:
    def out(page):
        username=getpass.getuser()
        min = ((page-1)*10)+1
        max = page*10
        ind = 0
        with open("/users/" + username + "/envd/environres/jade/namelist.txt", "rt") as namelist:
            for name in namelist:
                ind=ind+1
                if ind<min:
                    if ind>max:
                        print(ind+". "+name)
        return
    def inp(page, chosenindex):
        username=getpass.getuser()
        rightindex=page*10+chosenindex
        index=0
        with open("/users/" + username + "/envd/environres/jade/pathlist.txt", "rt") as pathlist:
            for path in pathlist:
                index=index+1
                if rightindex==index:
                    os.system(path)
                    break
        return

def Main():
    username = getpass.getuser()
    page = 1
    while True:
        os.system("clear")
        print("Jade Menu")
        Lui.v1.interaction.separator()
        Lui.v1.interaction.envpanel("Desktop")
        print(" Welcome " + username)
        print("[=] Show more options")
        print("Apps:\n")
        engine.out(page)
        print("< Previous Page | Next Page >" if page!=1 else "Next Page >")
        print("Page: "+str(page)); 
        a = input()
        if a=="#":
            exit(0)
        if a=="=":
            power()
        if a=="<" and page>1:
            if page!=1:
                page = page - 1; continue
        if a==">":
            page = page + 1; continue
        a=engine.inp(page, a)
        if a==1:
            print("Invalid Input!")
            input()
        continue
    return


