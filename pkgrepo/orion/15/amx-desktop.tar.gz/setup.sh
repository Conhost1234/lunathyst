#!/bin/bash

hpath=/users/$1

    #here we initialise the desktop shit
mkdir $hpath/envd/environres/amx
mkdir $hpath/envd/environres/amx/desktop
>$hpath/envd/environres/amx/desktop/a1.txt
>$hpath/envd/environres/amx/desktop/a2.txt
>$hpath/envd/environres/amx/desktop/a3.txt
>$hpath/envd/environres/amx/desktop/a4.txt
>$hpath/envd/environres/amx/desktop/b1.txt
>$hpath/envd/environres/amx/desktop/b2.txt
>$hpath/envd/environres/amx/desktop/b3.txt
>$hpath/envd/environres/amx/desktop/b4.txt
>$hpath/envd/environres/amx/desktop/c1.txt
>$hpath/envd/environres/amx/desktop/c2.txt
>$hpath/envd/environres/amx/desktop/c3.txt
>$hpath/envd/environres/amx/desktop/c4.txt
>$hpath/envd/environres/amx/desktop/d1.txt
>$hpath/envd/environres/amx/desktop/d2.txt
>$hpath/envd/environres/amx/desktop/d3.txt
>$hpath/envd/environres/amx/desktop/d4.txt

>$hpath/envd/environres/amx/desktop/a1.sh
>$hpath/envd/environres/amx/desktop/a2.sh
>$hpath/envd/environres/amx/desktop/a3.sh
>$hpath/envd/environres/amx/desktop/a4.sh
>$hpath/envd/environres/amx/desktop/b1.sh
>$hpath/envd/environres/amx/desktop/b2.sh
>$hpath/envd/environres/amx/desktop/b3.sh
>$hpath/envd/environres/amx/desktop/b4.sh
>$hpath/envd/environres/amx/desktop/c1.sh
>$hpath/envd/environres/amx/desktop/c2.sh
>$hpath/envd/environres/amx/desktop/c3.sh
>$hpath/envd/environres/amx/desktop/c4.sh
>$hpath/envd/environres/amx/desktop/d1.sh
>$hpath/envd/environres/amx/desktop/d2.sh
>$hpath/envd/environres/amx/desktop/d3.sh
>$hpath/envd/environres/amx/desktop/d4.sh

cp /lunathyst/dtwp/img01.lcp $hpath/envd/environres/amx.desktop.wallpaper.lcp

