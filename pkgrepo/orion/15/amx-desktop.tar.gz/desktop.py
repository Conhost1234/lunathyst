#!/usr/bin/python3
import subprocess
import random
import os
import time
import getpass
import llfman
import shexec
import LunUI as UI
import branding
import svc_EventSoundService as evsound
username=getpass.getuser()

#Amethyst desktop 1.0

class Settings:
    def Customisation():
        os.system("clear")
        UI.v1.interaction.envbutton(ctrl="#", msg="Exit/Cancel")
        UI.v1.interaction.envbutton(ctrl="1", msg="Default 01 - Crystal")
        UI.v1.interaction.envbutton(ctrl="/", msg="Custom")
        a=input()
        if a=="#":
            return
        if a=="1":
            os.system("cp /lunathyst/dtwp/img01.lcp " + "/users/" + username + "/envd/environres/amx.desktop.wallpaper.lcp")
            return
        if a=="/":
            print("Enter a filename without the extension\nCustom wallpapers must be located in your personal picture folder")
            b=input(":")
            if b=="#":
                return
            os.system("cp /users/" + username + "/pics/" + b + ".lcp " + "/users/" + username + "/envd/environres/amx.desktop.wallpaper.lcp")
            return
        return
    def PinnedApps():
        os.system("clear")
        UI.v1.interaction.envbutton(ctrl="#", msg="Exit/Cancel")
        a=input("Coordinate: ")
        if a=="#":
            exit()
        b=input("Name: ")
        if b=="#":
            exit()
        c=input("Path: ")
        if c=="#":
            exit()
        open("/users/" + username + "/envd/environres/amx/desktop/" + a + ".txt", "wt").write(b)
        open("/users/" + username + "/envd/environres/amx/desktop/" + a + ".sh", "wt").write(c)
        exit()
        return

def main():
    os.system("clear")
    username = getpass.getuser()
    a1 = open("/users/" + username + "/envd/environres/amx/desktop/a1.txt").read()
    b1 = open("/users/" + username + "/envd/environres/amx/desktop/b1.txt").read()
    c1 = open("/users/" + username + "/envd/environres/amx/desktop/c1.txt").read()
    d1 = open("/users/" + username + "/envd/environres/amx/desktop/d1.txt").read()
    a2 = open("/users/" + username + "/envd/environres/amx/desktop/a2.txt").read()
    b2 = open("/users/" + username + "/envd/environres/amx/desktop/b2.txt").read()
    c2 = open("/users/" + username + "/envd/environres/amx/desktop/c2.txt").read()
    d2 = open("/users/" + username + "/envd/environres/amx/desktop/d2.txt").read()
    a3 = open("/users/" + username + "/envd/environres/amx/desktop/a3.txt").read()
    b3 = open("/users/" + username + "/envd/environres/amx/desktop/b3.txt").read()
    c3 = open("/users/" + username + "/envd/environres/amx/desktop/c3.txt").read()
    d3 = open("/users/" + username + "/envd/environres/amx/desktop/d3.txt").read()
    a4 = open("/users/" + username + "/envd/environres/amx/desktop/a4.txt").read()
    b4 = open("/users/" + username + "/envd/environres/amx/desktop/b4.txt").read()
    c4 = open("/users/" + username + "/envd/environres/amx/desktop/c4.txt").read()
    d4 = open("/users/" + username + "/envd/environres/amx/desktop/d4.txt").read()
    while True:
        os.system("clear")
        UI.v1.interaction.envpanel("Menu", "#")
        print(time.strftime("%H:%M:%S")+"                                    Speaker/Headphone vol. mixer [;]")
        print(" Welcome " + username)
        print("--------------------------------------------------------------------------------")
        print("      A              B              C              D")
        print("1.  " + a1 + b1 + c1 + d1)
        print("2.  " + a2 + b2 + c2 + d2)
        print("3.  " + a3 + b3 + c3 + d3)
        print("4.  " + a4 + b4 + c4 + d4)
        print("--------------------------------------------------------------------------------")
        if os.path.exists("/users/" + username + "/envd/environres/amx.desktop.wallpaper.lcp"):
            os.system("cat /users/" + username + "/envd/environres/amx.desktop.wallpaper.lcp")
        inp = input(":")
        if inp=="":
            continue
        if inp=="#":
            os.system("python3 /lunathyst/menu.py")
        elif inp==";":
            os.system("alsamixer")
        else:
            try:
                if os.path.exists(str("/users/" + username + "/envd/environres/amx/desktop/" + inp+ ".sh")):
                    subprocess.Popen(["/bin/bash",str("/users/" + username + "/envd/environres/amx/desktop/" + inp+ ".sh")])
            except:
                continue
        continue

main()
