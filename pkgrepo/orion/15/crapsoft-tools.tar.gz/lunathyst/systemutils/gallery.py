# Text Gallery
import os
import LunUI

def view(file):
    os.system("clear")
    print("Text Art Gallery")
    LunUI.v1.interaction.separator()
    print("\n")
    os.system(f"cat /users/$USER/pics/{file}")
    input("\nPress Enter to continue")

def main():
    while True:
        os.system("clear")
        print("Text Art Gallery")
        LunUI.v1.interaction.separator()
        print("\n")
        LunUI.v1.interaction.envbutton(ctrl="#", msg="Exit"); print()
        os.system("ls /users/$USER/pics/")
        pic=input()
        if pic=="#":
            exit()
        view(pic)

main()