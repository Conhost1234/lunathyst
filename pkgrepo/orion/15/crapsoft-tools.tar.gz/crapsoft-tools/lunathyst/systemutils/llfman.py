import os

def read(file):
    cosm_ui_elements = []
    initused=False

    with open("/lunathyst/cosm/ui.llf", "rt") as cosm_ui:
        b=False
        element = ""
        section = -1
        rsrc = []
        app = []
        for a in cosm_ui:
            if "initf" in a:
                initused=True
            if "man sec, rsrc" in a:
                section=0
            if "man sec, app" in a:
                section=1
            if "return, sec -1" in a:
                section==-1
            if "return, endf" in a:
                section==-1
                initused==False
            if initused:
                if a=="&":
                    b=False
                    if section==0:
                        rsrc = list.append(rsrc, element)
                    if section==1:
                        app = list.append(app, element)
                    element=""; continue
                if b:
                    element=element+a
                if a=="element":
                    b=True
        return cosm_ui_elements