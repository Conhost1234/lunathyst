#!/bin/python
import llfman as llf
import LunUI as UI
import os
import getpass

def main():
    nm = getpass.getuser()
    while True:
        os.system("clear")
        print("Simple Notes")
        UI.v1.interaction.separator()
        UI.v1.interaction.envbutton("#", "Exit")
        UI.v1.interaction.envbutton(";", "Delete notes")
        if os.path.exists("/users/" + nm + "/docs/note.txt"):
            os.system("cat " + "/users/" + nm + "/docs/note.txt")
        else:
            open("/users/" + nm + "/docs/note.txt", "x")
            continue
        a = input("Simplenotes >> ")
        if a=="#":
            break
        elif a==";":
            os.system("rm " + "/users/" + nm + "/docs/note.txt")
            open("/users/" + nm + "/docs/note.txt", "x")
            continue
        else:
            with open("/users/" + nm + "/docs/note.txt", "a") as f:
                f.write(a + "\n")
        continue
    return

main()
