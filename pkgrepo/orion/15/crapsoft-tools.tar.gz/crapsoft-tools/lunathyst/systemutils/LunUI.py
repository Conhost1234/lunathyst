import random
import time
import math
import os
import branding

src1="/lunathyst/cosm/ui.llf"

def modulerelease():
    return "1.0"
def moduleseries():
    return "crapsoft lunathyst interface API v1"
def modulebuild():
    return "v1"

class v1:
    #ltx interface library 1.0, internal build v1
    class colours:
        black=0
        maroon=1
        green=2
        olive=3
        navy=4
        purple=5
        teal=6
        silver=7
        grey=8
        red=9
        lime=10
        yellow=10
        blue=12
        fuchsia=13
        aqua=14
        white=15

    class interaction:
        def separator():
            print("----------------------------------------------------------------------------------------")
            return
        def envbutton(ctrl, msg):
            print("["+ctrl+"] " + msg)
            return
        def envpanel(name="", ctrl=""):
            if ctrl!="":
                print("                  " + branding.desktop +"                             "+ name +"-[" + ctrl +"]" + "\n----------------------------------------------------------------------------------------")
                return
            else:
                print("                  " + branding.desktop +"                             " + "\n----------------------------------------------------------------------------------------"); return
            return; return 0
    class data:
        def envtime(ctrl, msg):
            return time.strftime("%a %d %b %H:%M")
    class promptmsgbox:
        def information(infoline1, program):
            os.system("clear")
            print("i     i     i     i     i     i     i     i     i     i")
            print("<i> " + program)
            print("--------------------------------------------------------")
            print(infoline1)
            print("Press enter to continue")
            input()
            return 0
        def warn(warnline1, program, showwarntext=True):
            os.system("clear")
            print("!     !     !     !     !     !     !     !     !     !")
            print("<!> " + program)
            print("--------------------------------------------------------")
            print("Warning: " if showwarntext else "" + warnline1)
            print("Press enter to continue")
            input()
            return 0
        def error(errline1, program, showerrtext=True, errcode="system.api.ltx_interface.svcinp.errcode==system.api.val(empty)"):
            os.system("clear")
            print("x     x     x     x     x     x     x     x     x     x")
            print("<x> "  + program)
            print("--------------------------------------------------------")
            print("Error: " if showerrtext else "" + errline1)
            if errcode!="null":
                print("Exit Code: ", errcode)
            print("Press enter to continue")
            input()
            return 0
