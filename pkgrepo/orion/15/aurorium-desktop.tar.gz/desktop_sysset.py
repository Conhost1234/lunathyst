#!/usr/bin/python3
import subprocess
import random
import os
import time
import getpass
import llfman
import shexec
import LunUI as UI
import branding
username=getpass.getuser()

#Amethyst desktop 1.0

class Settings:
    def Customisation():
        os.system("clear")
        UI.v1.interaction.envbutton(ctrl="#", msg="Exit/Cancel")
        UI.v1.interaction.envbutton(ctrl="1", msg="Default 01 - Mountains")
        UI.v1.interaction.envbutton(ctrl="/", msg="Custom")
        a=input()
        if a=="#":
            return
        if a=="1":
            os.system("cp /apps/aurorium-desktop/img1.lcp " + "/users/" + username + "/envd/environres/aur/wp.lcp")
            return
        if a=="/":
            print("Enter a filename without the extension\nCustom wallpapers must be located in your personal picture folder")
            b=input(":")
            if b=="#":
                return
            os.system("cp /users/" + username + "/pics/" + b + ".lcp " + "/users/" + username + "/envd/environres/aur/wp.lcp")
            return
        return
    def PinnedApps():
        os.system("clear")
        UI.v1.interaction.envbutton(ctrl="#", msg="Exit/Cancel")
        a=input("Coordinate: ")
        if a=="#":
            exit()
        c=input("Path: ")
        if c=="#":
            exit()
        print("Is this a graphical application?")
        UI.v1.interaction.envbutton(ctrl="1", msg="Yes")
        UI.v1.interaction.envbutton(ctrl="2", msg="No")
        d=input()
        cmd=""
        if d=="1":
            cmd="setsid ";
        os.system(f"echo {cmd}{c} > /users/$USER/envd/environres/aur/pinned/{a}.sh")
        exit()
        return
