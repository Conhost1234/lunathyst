#!/bin/bash

mkdir /users/$1/envd/environres/aur/
mkdir /users/$1/envd/environres/aur/pinned/
cp /apps/aurorium-desktop/img1.lcp /users/$1/envd/environres/aur/wp.lcp

