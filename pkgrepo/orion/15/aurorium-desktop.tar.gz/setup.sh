#!/bin/bash

mkdir /users/$USER/envd/environres/aur/
cp /apps/aurorium-desktop/img1.lcp /users/$USER/envd/environres/aur/wp.lcp

