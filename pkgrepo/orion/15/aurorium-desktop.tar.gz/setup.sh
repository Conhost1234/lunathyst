#!/bin/bash

mkdir /users/$USER/envd/environres/aur/
mkdir /users/$USER/envd/environres/aur/pinned/
cp /apps/aurorium-desktop/img1.lcp /users/$USER/envd/environres/aur/wp.lcp

