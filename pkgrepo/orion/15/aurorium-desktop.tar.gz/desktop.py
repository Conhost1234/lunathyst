import os; import getpass; import time
def main():
    while True:
        os.system("clear"); uname=getpass.getuser()
        os.system("cat /users/"+uname+"/envd/environres/aur/wp.lcp");os.system("ls /users/"+uname+"/envd/environres/aur/pinned"); print("# Menu ------------> "+time.strftime("%H:%M:%S")+" --Aurorium Desktop--> :]"); a=input()
        if a=="#":
            os.system("python3 /lunathyst/menu.py")
        else:
            os.system("/users/"+uname+"/envd/environres/aur/pinned/"+a+".sh")
main()